/*
 Navicat Premium Data Transfer

 Source Server         : 本机数据库
 Source Server Type    : MySQL
 Source Server Version : 50725
 Source Host           : localhost:3306
 Source Schema         : bank1

 Target Server Type    : MySQL
 Target Server Version : 50725
 File Encoding         : 65001

 Date: 04/03/2021 21:12:35
*/
CREATE DATABASE bank1;
USE bank2;

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for account
-- ----------------------------
DROP TABLE IF EXISTS `account`;
CREATE TABLE `account`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `account_name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '户名',
  `account_no` char(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '账号',
  `balance` decimal(12, 2) UNSIGNED NOT NULL COMMENT '账户余额',
  `bank_no` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '银行编码',
  `created_time` bigint(20) NOT NULL COMMENT '创建时间',
  `updated_time` bigint(20) NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of account
-- ----------------------------
INSERT INTO `account` VALUES (1, '张三', '6235666688889999', 9999944.00, '22222', 1614768747000, 1614768747000);

-- ----------------------------
-- Table structure for transfer_sequence
-- ----------------------------
DROP TABLE IF EXISTS `transfer_sequence`;
CREATE TABLE `transfer_sequence`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `trade_no` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '交易流水ID',
  `account_no` char(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '源银行卡号',
  `target_bank_no` char(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '目标银行编码',
  `bank_no` char(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '源银行编码',
  `target_account_no` char(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '目标银行卡号',
  `amount` decimal(12, 2) NOT NULL COMMENT '交易金额',
  `status` tinyint(1) NOT NULL COMMENT '0-待处理， 1-处理成功， 2-处理失败',
  `created_time` bigint(20) NOT NULL COMMENT '创建时间',
  `updated_time` bigint(20) NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `tid_unique_idx`(`trade_no`) USING BTREE COMMENT '交易流水号是唯一ID'
) ENGINE = InnoDB AUTO_INCREMENT = 18 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of transfer_sequence
-- ----------------------------
INSERT INTO `transfer_sequence` VALUES (9, 'thlY7VeJX0OqWXBmbtS7vAIjyOxAw2xB', '张三', '1111', '22222', '李四', 1.00, 1, 1614806592493, 1614806592493);
INSERT INTO `transfer_sequence` VALUES (11, 'suDnXIuQXdMB0HVEqtxREtZVbRGlIZqm', '张三', '1111', '22222', '李四', 1.00, 1, 1614832037910, 1614832037910);
INSERT INTO `transfer_sequence` VALUES (13, 'gWEtO4ZwhOgAAquspSlmQY5AWG9gNxZH', '张三', '1111', '22222', '李四', 1.00, 1, 1614841021734, 1614841021734);
INSERT INTO `transfer_sequence` VALUES (14, 'fwL2xPAIkjShrlv04aXbz6vMp0RuNXgP', '张三', '1111', '22222', '李四', 1.00, 1, 1614842753980, 1614842753980);
INSERT INTO `transfer_sequence` VALUES (15, '6cUWBRB5gpH1bV2KykNtry9Nursf66kW', '张三', '1111', '22222', '李四', 16.00, 1, 1614842842147, 1614842842147);
INSERT INTO `transfer_sequence` VALUES (16, '5tkv9wEbSX0Dvohi8G8V4KJSxLlzVwmr', '张三', '1111', '22222', '李四', 16.00, 1, 1614845198285, 1614845198285);
INSERT INTO `transfer_sequence` VALUES (17, 'MiNNLhwDjwDQ05WIBq9eIGKG9CSPG11H', '张三', '1111', '22222', '李四', 16.00, 1, 1614855442350, 1614855442350);

SET FOREIGN_KEY_CHECKS = 1;
