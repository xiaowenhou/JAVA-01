/*
 Navicat Premium Data Transfer

 Source Server         : 本机数据库
 Source Server Type    : MySQL
 Source Server Version : 50725
 Source Host           : localhost:3306
 Source Schema         : bank2

 Target Server Type    : MySQL
 Target Server Version : 50725
 File Encoding         : 65001

 Date: 04/03/2021 21:12:42
*/

CREATE DATABASE bank2;
USE bank2;

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for account
-- ----------------------------
DROP TABLE IF EXISTS `account`;
CREATE TABLE `account`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `account_name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '户名',
  `account_no` char(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '账号',
  `balance` decimal(12, 2) UNSIGNED NOT NULL COMMENT '账户余额',
  `bank_no` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '银行编码',
  `created_time` bigint(20) NOT NULL COMMENT '创建时间',
  `updated_time` bigint(20) NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of account
-- ----------------------------
INSERT INTO `account` VALUES (1, '李四', '6212268889996668888', 52.00, '1111', 1614768818000, 1614768818000);

-- ----------------------------
-- Table structure for transfer_sequence
-- ----------------------------
DROP TABLE IF EXISTS `transfer_sequence`;
CREATE TABLE `transfer_sequence`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `trade_no` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '交易流水ID',
  `account_no` char(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '源银行卡号',
  `bank_no` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '源银行编码',
  `target_bank_no` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '目标银行编码',
  `target_account_no` char(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '目标银行卡号',
  `amount` decimal(12, 2) NOT NULL COMMENT '交易金额',
  `status` tinyint(1) NOT NULL COMMENT '0-待处理， 1-处理成功， 2-处理失败',
  `created_time` bigint(20) NOT NULL COMMENT '创建时间',
  `updated_time` bigint(20) NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `tid_unique_idx`(`trade_no`) USING BTREE COMMENT '交易流水号，唯一索引'
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of transfer_sequence
-- ----------------------------
INSERT INTO `transfer_sequence` VALUES (1, 'thlY7VeJX0OqWXBmbtS7vAIjyOxAw2xB', '张三', '22222', '1111', '李四', 1.00, 1, 1614806692715, 1614806692715);
INSERT INTO `transfer_sequence` VALUES (2, 'suDnXIuQXdMB0HVEqtxREtZVbRGlIZqm', '张三', '22222', '1111', '李四', 1.00, 1, 1614832037927, 1614832037927);
INSERT INTO `transfer_sequence` VALUES (3, 'gWEtO4ZwhOgAAquspSlmQY5AWG9gNxZH', '张三', '22222', '1111', '李四', 1.00, 1, 1614841021764, 1614841021764);
INSERT INTO `transfer_sequence` VALUES (4, 'fwL2xPAIkjShrlv04aXbz6vMp0RuNXgP', '张三', '22222', '1111', '李四', 1.00, 1, 1614842754038, 1614842754038);
INSERT INTO `transfer_sequence` VALUES (5, '6cUWBRB5gpH1bV2KykNtry9Nursf66kW', '张三', '22222', '1111', '李四', 16.00, 1, 1614842842172, 1614842842172);
INSERT INTO `transfer_sequence` VALUES (6, '5tkv9wEbSX0Dvohi8G8V4KJSxLlzVwmr', '张三', '22222', '1111', '李四', 16.00, 1, 1614845198307, 1614845198307);
INSERT INTO `transfer_sequence` VALUES (7, 'MiNNLhwDjwDQ05WIBq9eIGKG9CSPG11H', '张三', '22222', '1111', '李四', 16.00, 1, 1614855442375, 1614855442375);

SET FOREIGN_KEY_CHECKS = 1;
